# Glass AI

Flutter source project for the Glass AI Android app.

## Build an APK on GitHub

1. Upload the contents of this folder to the root of your GitHub repository.
2. Ensure the default branch is `main`.
3. Open Actions and enable workflows if GitHub asks.
4. Run Build Glass AI APK with Run workflow, or push a commit to main.
5. After a successful run, download the `Glass-AI-APK` artifact.
6. Extract the artifact archive to get `app-release.apk`, then install it on Android.

## Security

The app lets you enter a Groq API key in its settings for local testing. Do not distribute a public APK with a personal API key embedded or shared. Revoke any key exposed in chat and use a backend proxy for a public release.

## Scope

This version includes the glassmorphism chat UI, model selection, and Groq chat completion request. Android Accessibility automation, floating overlay, and file uploads are not implemented yet.
